package code.shubham.commons.constants;

public interface CommonConstants {

    String COMMAND_NOT_FOUND_EXCEPTION_MESSAGE = "Command %s not found";
}
