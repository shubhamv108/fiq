package code.shubham.fiq.constants;

public interface FIQConstants {
}
